python3 update.py && python3 -m bot
