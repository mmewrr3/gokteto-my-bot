rin() {
pip install --upgrade pip
pip install anytree
pip install appdirs
pip install aria2p
pip install attrdict
pip install beautifulsoup4
pip install bencoding
pip install cfscrape
pip install feedparser
pip install flask
pip install google-api-python-client
pip install google-auth-httplib2
pip install google-auth-oauthlib
pip install gunicorn
pip install lk21
pip install lxml
pip install pillow
pip install psutil
pip install psycopg2-binary
pip install pybase64
pip install python-dotenv
pip install python-magic
pip install python-telegram-bot
pip install qbittorrent-api
pip install requests
pip install speedtest-cli
pip install six
pip install telegraph
pip install tenacity
pip install tgCrypto
pip install urllib3
pip install yt-dlp
pip install google-api-python-client
pip install progress
pip install progressbar2
pip install httplib2shim
pip install google_auth_oauthlib
pip install pyrogram
pip install megasdkrestclient
}
dl() {
apt update -y
apt upgrade -y
apt install sudo
apt install aria2 -y || sudo apt install aria2 -y
apt install wget -y || sudo apt install wget -y
apt install apt-utils -y || sudo apt install apt-utils -y
rin
}
dl
